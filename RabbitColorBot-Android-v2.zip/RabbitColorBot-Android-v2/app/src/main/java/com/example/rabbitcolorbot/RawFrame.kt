package com.example.rabbitcolorbot

import android.graphics.Color
import java.nio.ByteBuffer

/**
 * Lightweight view over a single MediaProjection RGBA_8888 frame.
 *
 * The old code allocated a full-screen Bitmap + IntArray every frame, which is
 * slow and produces heavy GC pressure in a real-time loop. Here we keep the raw
 * plane buffer and read only the pixels we actually need (the target region and
 * the four answer slots), so per-frame work drops from ~millions of pixels to a
 * few hundred samples.
 */
class RawFrame(
    private val buffer: ByteBuffer,
    val width: Int,
    val height: Int,
    private val rowStride: Int,
    private val pixelStride: Int
) {
    /** Returns an ARGB int for the pixel at (x, y). Coordinates are clamped. */
    fun pixel(x: Int, y: Int): Int {
        val cx = x.coerceIn(0, width - 1)
        val cy = y.coerceIn(0, height - 1)
        val off = cy * rowStride + cx * pixelStride
        val r = buffer.get(off).toInt() and 255
        val g = buffer.get(off + 1).toInt() and 255
        val b = buffer.get(off + 2).toInt() and 255
        return Color.rgb(r, g, b)
    }
}
