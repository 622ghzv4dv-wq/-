package com.example.rabbitcolorbot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * A small always-on-top button so the user can flip the bot on/off without
 * leaving the game. Draggable; tap toggles. Green = ON, gray = OFF.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var button: TextView
    private lateinit var lp: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        startForeground(8, notif())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        button = TextView(this).apply {
            text = "OFF"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(36, 22, 36, 22)
            setBackgroundColor(0xCC444444.toInt())
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 300
        }

        attachTouch()
        wm.addView(button, lp)
    }

    private fun attachTouch() {
        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0
        var moved = false

        button.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX)
                    val dy = (e.rawY - downY)
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) moved = true
                    lp.x = startX + dx.roundToInt()
                    lp.y = startY + dy.roundToInt()
                    wm.updateViewLayout(button, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) setOn(BotState.toggle())
                    true
                }
                else -> false
            }
        }
    }

    private fun setOn(on: Boolean) {
        button.text = if (on) "ON" else "OFF"
        button.setBackgroundColor(if (on) 0xEE1FA855.toInt() else 0xCC444444.toInt())
    }

    private fun notif(): Notification {
        val ch = "rabbit_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(
                NotificationChannel(ch, "Rabbit Overlay", NotificationManager.IMPORTANCE_MIN)
            )
        }
        return Notification.Builder(this, ch)
            .setContentTitle("Rabbit Color Bot")
            .setContentText("토글 버튼 표시 중")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        if (this::button.isInitialized) wm.removeView(button)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
