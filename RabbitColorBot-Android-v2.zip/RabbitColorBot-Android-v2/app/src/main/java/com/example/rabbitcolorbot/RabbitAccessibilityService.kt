package com.example.rabbitcolorbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class RabbitAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: RabbitAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // Required abstract members of AccessibilityService. We don't react to
    // accessibility events (we only dispatch taps), so these stay empty.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 35))
            .build()

        dispatchGesture(gesture, null, null)
    }
}
