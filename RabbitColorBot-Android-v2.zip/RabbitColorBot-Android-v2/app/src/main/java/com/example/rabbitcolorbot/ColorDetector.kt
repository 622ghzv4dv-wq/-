package com.example.rabbitcolorbot

import android.graphics.Color
import kotlin.math.abs
import kotlin.math.min

/**
 * Detects the target rabbit color and picks the matching answer slot.
 *
 * Improvements over the hue-only version:
 *  - Samples directly from RawFrame (no per-frame Bitmap allocation).
 *  - Classifies each region into one of the discrete rabbit token colors
 *    (red / orange / yellow / green / teal / blue / purple / pink) instead of
 *    comparing raw hue. Class matching is far more robust for near hues like
 *    red↔pink or green↔teal, which pure hue distance confuses.
 *  - Confidence gating so it only taps when the screen really shows a round.
 */
object ColorDetector {

    // Normalized rectangles (fractions of screen). Adjust in one place if the
    // layout differs. Defaults are calibrated from the supplied screenshots
    // (single-player rabbit panel, answer slots along the bottom).
    data class R(val x: Float, val y: Float, val w: Float, val h: Float)

    @Volatile var target = R(0.34f, 0.25f, 0.32f, 0.22f)

    @Volatile var choices = arrayOf(
        R(0.13f, 0.70f, 0.17f, 0.20f),
        R(0.34f, 0.70f, 0.17f, 0.20f),
        R(0.55f, 0.70f, 0.17f, 0.20f),
        R(0.76f, 0.70f, 0.17f, 0.20f)
    )

    /** Discrete rabbit colors as HSV hue anchors (degrees). */
    private enum class Token(val hue: Float) {
        RED(2f), ORANGE(30f), YELLOW(52f), GREEN(120f),
        TEAL(168f), BLUE(210f), PURPLE(280f), PINK(330f)
    }

    private data class Sample(val token: Token, val confidence: Float)

    /** Returns tap point (px) for the answer matching the target, or null. */
    fun solve(f: RawFrame): Pair<Float, Float>? {
        val want = classify(f, target) ?: return null
        if (want.confidence < 0.30f) return null

        var best = -1
        var bestConf = 0f
        for (i in choices.indices) {
            val c = classify(f, choices[i]) ?: continue
            if (c.token == want.token && c.confidence > bestConf) {
                best = i
                bestConf = c.confidence
            }
        }
        if (best < 0) return null

        val r = choices[best]
        return Pair(
            (r.x + r.w / 2f) * f.width,
            (r.y + r.h / 2f) * f.height
        )
    }

    /** Dominant rabbit color in a region + how strongly it dominates (0..1). */
    private fun classify(f: RawFrame, r: R): Sample? {
        val x0 = (r.x * f.width).toInt()
        val y0 = (r.y * f.height).toInt()
        val x1 = ((r.x + r.w) * f.width).toInt()
        val y1 = ((r.y + r.h) * f.height).toInt()

        // Trim 15% border to avoid frames/labels.
        val sx = x0 + ((x1 - x0) * 0.15f).toInt()
        val ex = x1 - ((x1 - x0) * 0.15f).toInt()
        val sy = y0 + ((y1 - y0) * 0.15f).toInt()
        val ey = y1 - ((y1 - y0) * 0.15f).toInt()
        if (ex - sx < 4 || ey - sy < 4) return null

        val votes = IntArray(Token.entries.size)
        var samples = 0
        val hsv = FloatArray(3)

        var y = sy
        while (y < ey) {
            var x = sx
            while (x < ex) {
                Color.colorToHSV(f.pixel(x, y), hsv)
                // Ignore near-gray / dark (background, outlines, the white face).
                if (hsv[1] > 0.30f && hsv[2] > 0.28f) {
                    votes[nearestToken(hsv[0]).ordinal]++
                    samples++
                }
                x += 5
            }
            y += 5
        }
        if (samples < 10) return null

        var top = 0
        for (i in 1 until votes.size) if (votes[i] > votes[top]) top = i
        val conf = votes[top].toFloat() / samples
        return Sample(Token.entries[top], conf)
    }

    private fun nearestToken(hue: Float): Token {
        var best = Token.RED
        var bestD = Float.MAX_VALUE
        for (t in Token.entries) {
            val d = hueDistance(hue, t.hue)
            if (d < bestD) { bestD = d; best = t }
        }
        return best
    }

    private fun hueDistance(a: Float, b: Float): Float {
        val d = abs(a - b)
        return min(d, 360f - d)
    }
}
