package com.example.rabbitcolorbot

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*

class CaptureService : Service() {
    companion object {
        private const val CH = "rabbit_capture"
        private const val NOTIF = 7
        // Minimum gap between taps. The round advances after each correct hit,
        // so this bounds throughput; low enough to be fast, high enough to let
        // the next color render before we read again.
        private const val TAP_COOLDOWN_MS = 130L

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, CaptureService::class.java)
                .putExtra("resultCode", resultCode)
                .putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i)
            else ctx.startService(i)
        }
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var lastTap = 0L

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("capture").also { it.start() }
        handler = Handler(thread.looper)
        createChannel()
        startForeground(NOTIF, notif())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                // Cheap early-outs before any pixel work.
                val now = SystemClock.uptimeMillis()
                if (BotState.running.get() && now - lastTap >= TAP_COOLDOWN_MS) {
                    val plane = image.planes[0]
                    val frame = RawFrame(
                        plane.buffer, w, h, plane.rowStride, plane.pixelStride
                    )
                    val tap = ColorDetector.solve(frame)
                    if (tap != null) {
                        RabbitAccessibilityService.instance?.tap(tap.first, tap.second)
                        lastTap = now
                    }
                }
            } finally {
                image.close()
            }
        }, handler)

        display = projection!!.createVirtualDisplay(
            "RabbitColorBot",
            w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
    }

    private fun notif(): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("Rabbit Color Bot")
            .setContentText("화면 색상 감지 중")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "Rabbit Color Bot", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        if (this::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
}
