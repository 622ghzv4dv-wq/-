package com.example.rabbitcolorbot

import java.util.concurrent.atomic.AtomicBoolean

/** Global on/off switch, flipped by the floating toggle button. */
object BotState {
    val running = AtomicBoolean(false)
    fun toggle(): Boolean {
        val v = !running.get()
        running.set(v)
        return v
    }
}
