package com.example.rabbitcolorbot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    companion object { private const val REQ_CAPTURE = 1001 }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            text = "1) 접근성 서비스 켜기\n2) 다른 앱 위에 표시 허용\n3) 화면 캡처 시작\n4) 게임에서 ON 버튼 탭"
            textSize = 16f
            setPadding(32, 32, 32, 32)
        }

        val enableAccess = Button(this).apply {
            text = "① 접근성 설정 열기"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val enableOverlay = Button(this).apply {
            text = "② 오버레이 권한 열기"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    status.text = "오버레이 권한 이미 허용됨."
                }
            }
        }

        val start = Button(this).apply {
            text = "③ 화면 캡처 시작"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(enableAccess)
            addView(enableOverlay)
            addView(start)
        }
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            CaptureService.start(this, resultCode, data)
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                OverlayService.start(this)
                status.text = "실행 중. 게임을 열고 화면 위 ON 버튼으로 켜고 끄세요."
            } else {
                status.text = "오버레이 권한을 먼저 허용하세요 (② 버튼)."
            }
            // Move app to background so capture starts on the game screen.
            moveTaskToBack(true)
        }
    }
}
